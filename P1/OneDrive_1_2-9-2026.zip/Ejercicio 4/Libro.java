public class Libro {
    private String isbn;
    private String titulo;
    private String autor;
    private int ejemplaresDisponibles = 0;
    private int annoPublicacion = -1;
    private String genero = "Sin género";

    public Libro(String isbn, String titulo, String autor) {
        this.isbn = isbn;
        this.titulo = titulo;
        this.autor = autor;
    }

    public Libro(String isbn, String titulo, String autor, int ejemplaresDisponibles) {
        this(isbn, titulo, autor);
        this.ejemplaresDisponibles = ejemplaresDisponibles;
    }

    public Libro(String isbn, String titulo, String autor, int ejemplaresDisponibles, String genero, int annoPublicacion) {
        this(isbn, titulo, autor, ejemplaresDisponibles);
        this.genero = genero;
        this.annoPublicacion = annoPublicacion;
    }

    public String tomarGenero() {
        return this.genero;
    }
    public int tomarAnnoPublicacion() {
        return this.annoPublicacion;
    }


    // Método para verificar si el libro está disponible
    public boolean estaDisponible() {
        return this.ejemplaresDisponibles > 0;
    }

    public boolean tieneGenero() {
        if (this.genero.compareTo("Sin género") == 0) {
            return false;
        }
        return true;
    }

    public boolean tieneAnnoPublicacion() {
        if (this.annoPublicacion == -1) {
            return false;
        }
        return true;
    }

    // Método para prestar el libro
    public boolean prestar() {
        if (estaDisponible()) {
            this.ejemplaresDisponibles--;
            return true;
        }
        return false;
    }

    // Método para devolver el libro
    public void devolver() {
        this.ejemplaresDisponibles++;
    }

    // Método para obtener la descripción del libro
    private String descripcion() {
        String annoPublicacion = this.tieneAnnoPublicacion() ? ", Año publicación: " + this.annoPublicacion : "";
        String genero = this.tieneGenero() ? ", Género: " + this.genero : "";
        String estado = this.estaDisponible() ? "Disponible" : "No disponible";
        return "'"+this.titulo+"' de " + this.autor + genero + annoPublicacion + " [" + estado + "]";
    }

    @Override
    public String toString() {
        return "ISBN: " + this.isbn + ". " + this.descripcion() + " (" + this.ejemplaresDisponibles +
                " ejemplares disponibles)";
    }
}