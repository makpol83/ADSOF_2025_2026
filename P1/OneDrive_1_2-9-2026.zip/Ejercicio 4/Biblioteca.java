import java.util.*;

public class Biblioteca {
    private String nombre;
    private HashMap<String, List<Libro>> libros;
    private int tamanno_inicial = 10;

    public Biblioteca(String nombre) {
        this.nombre = nombre;
        this.libros = new HashMap<>(tamanno_inicial);
    }

    public Biblioteca(String nombre, List<Libro> libros) {
        this(nombre);
        for (Libro l : libros) {
            String genero = l.tomarGenero();

            if(this.libros.containsKey(genero) == false) {
                this.libros.put(genero, new ArrayList<> (List.of(l)));

            } else {
                List<Libro> lista = this.libros.get(genero);
                lista.add(l);
            }
        }
    }

    public List<Libro> librosPorGenero(String genero) {
        List<Libro> libros = new ArrayList<> (List.of());
        if(this.libros.containsKey(genero) == false) {
            return libros;
        }
        // Devuelve la lista, no una copia
        return this.libros.get(genero);
    }

    public List<Libro> librosPosterioresA(int añoPublicacion) {
        List<Libro> libros = new ArrayList<> (List.of());

        for (List<Libro> lista : this.libros.values()) {
            for (Libro l : lista) {
                int fecha = l.tomarAnnoPublicacion();
                if (fecha > añoPublicacion && fecha != -1) {
                    libros.add(l);
                }
            }
        }

        return libros;
    }


}
